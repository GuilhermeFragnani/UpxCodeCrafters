package application;

import entities.Usuario;
import javax.swing.JOptionPane;

public class Program {

    public static void main(String[] args) {
        Usuario usuario = new Usuario();

        boolean sair = false;

        while (!sair) {
            String opcao = JOptionPane.showInputDialog("Menu: \n" +
                                                        "1 - Cadastrar\n" +
                                                        "2 - Ver Perfil\n" +
                                                        "3 - Escolher Conteúdo\n" +
                                                        "4 - Visualizar Conteúdo\n" +
                                                        "5 - Sair");

            switch (opcao) {
                case "1":
                    String nome = JOptionPane.showInputDialog("Digite o seu nome: ");
                    usuario.setNome(nome);
                    String login = JOptionPane.showInputDialog("Crie um login: ");
                    usuario.setLogin(login);
                    String senha = JOptionPane.showInputDialog("Crie uma senha: ");
                    usuario.setSenha(senha);
                    break;
                case "2":
                    JOptionPane.showMessageDialog(null, usuario.imprimir(), "Perfil do Usuário", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case "3":
                    String[] opcoesConteudo = { "Programação", "Linguagens", "Matemática", "Ciências Exatas",
                                                "Ciências Humanas", "Ciências Biológicas", "Conhecimentos Técnicos" };
                    String conteudoEscolhido = (String) JOptionPane.showInputDialog(null, "Escolha um conteúdo:",
                                                                                      "Escolha de Conteúdo", JOptionPane.PLAIN_MESSAGE, null,
                                                                                      opcoesConteudo, opcoesConteudo[0]);
                    usuario.setConteudoEscolhido(conteudoEscolhido);
                    break;
                case "4":
                    JOptionPane.showMessageDialog(null, "Visualizando conteúdo de " + usuario.getConteudoEscolhido());
                    break;
                case "5":
                    sair = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida.", "ERRO", JOptionPane.ERROR_MESSAGE);
                    break;
            }
        }
    }
}
