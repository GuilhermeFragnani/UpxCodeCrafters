package entities;

public class Usuario {
    
    private String nome;
    private String login;
    private String senha;
    private String conteudoEscolhido;

    public Usuario() {}

    public Usuario(String nome, String login, String senha) {
        this.nome = nome;
        this.login = login;
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getConteudoEscolhido() {
        return conteudoEscolhido;
    }

    public void setConteudoEscolhido(String conteudoEscolhido) {
        this.conteudoEscolhido = conteudoEscolhido;
    }

    public String imprimir() {
        return "Nome: " + nome +
                "\nLogin: " + login +
                "\nConteúdo escolhido: " + conteudoEscolhido;
    }
}
