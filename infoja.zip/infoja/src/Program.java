import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Program {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/infoja";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "m7n10";

    public static void main(String[] args) {
        List<Usuario> usuariosCadastrados = new ArrayList<>();
        Usuario usuarioLogado = null;

        boolean sair = false;

        while (!sair) {
            String opcao = JOptionPane.showInputDialog(null,
                    "1 - Cadastrar Conta\n" +
                    "2 - Login / Trocar de Conta\n" +
                    "3 - Exibir Perfil\n" +
                    "4 - Escolher Disciplina\n" +
                    "5 - Escolher Matéria\n" +
                    "6 - Exibir Conteúdo\n" +
                    "7 - Excluir Conta\n" +
                    "8 - Sair",
                    "InfoJá (CodeCrafters) - Menu:",
                    JOptionPane.PLAIN_MESSAGE);

            switch (opcao) {
                case "1":
                    cadastrarUsuario();
                    break;
                case "2":
                    usuarioLogado = fazerLogin();
                    if (usuarioLogado != null) {
                        JOptionPane.showMessageDialog(null, "Login bem-sucedido. Olá " + usuarioLogado.getNome() + "!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Login falhou.", "ERRO", JOptionPane.ERROR_MESSAGE);
                    }
                    break;
                case "3":
                    if (usuarioLogado == null) {
                        JOptionPane.showMessageDialog(null, "Entre em uma conta primeiro.", "ERRO", JOptionPane.ERROR_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, usuarioLogado.imprimir(), "Perfil do Usuário", JOptionPane.PLAIN_MESSAGE);
                    }
                    break;
                case "4":
                    if (usuarioLogado == null) {
                        JOptionPane.showMessageDialog(null, "Entre em uma conta primeiro.", "ERRO", JOptionPane.ERROR_MESSAGE);
                    } else {
                        escolherConteudo(usuarioLogado);
                    }
                    break;
                case "5":
                    if (usuarioLogado == null || usuarioLogado.getDisciplinaId() == null) {
                        JOptionPane.showMessageDialog(null, "Escolha uma disciplina primeiro.", "ERRO", JOptionPane.ERROR_MESSAGE);
                    } else {
                        escolherMateria(usuarioLogado);
                    }
                    break;
                case "6":
                    if (usuarioLogado == null || usuarioLogado.getMateriaId() == null) {
                        JOptionPane.showMessageDialog(null, "Escolha uma matéria primeiro.", "ERRO", JOptionPane.ERROR_MESSAGE);
                    } else {
                        exibirConteudo(usuarioLogado);
                    }
                    break;
                case "7":
                    if (usuarioLogado != null) {
                        excluirConta(usuarioLogado);
                        usuarioLogado = null; // Resetando usuário logado após a exclusão da conta
                    } else {
                        JOptionPane.showMessageDialog(null, "Entre em uma conta primeiro.", "ERRO", JOptionPane.ERROR_MESSAGE);
                    }
                    break;
                case "8":
                    sair = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Esta opção não existe.", "ERRO", JOptionPane.ERROR_MESSAGE);
                    break;
            }
        }
    }

    private static void cadastrarUsuario() {
        String nome = JOptionPane.showInputDialog("Digite o seu nome: ");
        String email = JOptionPane.showInputDialog("Digite um email: ");
        String senha = JOptionPane.showInputDialog("Digite uma senha: ");

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)")) {
            stmt.setString(1, nome);
            stmt.setString(2, email);
            stmt.setString(3, senha);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Usuário cadastrado com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar usuário.", "ERRO", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static Usuario fazerLogin() {
        String email = JOptionPane.showInputDialog("Digite seu email: ");
        String senha = JOptionPane.showInputDialog("Digite sua senha: ");

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM usuarios WHERE email = ? AND senha = ?")) {
            stmt.setString(1, email);
            stmt.setString(2, senha);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                return new Usuario(id, nome, email, senha);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao fazer login.", "ERRO", JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }

    private static void escolherConteudo(Usuario usuarioLogado) {
        List<String> conteudos = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT nome FROM disciplinas")) {

            while (rs.next()) {
                conteudos.add(rs.getString("nome"));
            }

            String[] conteudosArray = conteudos.toArray(new String[0]);
            String conteudoEscolhido = (String) JOptionPane.showInputDialog(null, "Escolha uma disciplina:", "Disciplinas Disponíveis", JOptionPane.QUESTION_MESSAGE, null, conteudosArray, conteudosArray[0]);

            if (conteudoEscolhido != null) {
                try (PreparedStatement stmt2 = conn.prepareStatement("SELECT id FROM disciplinas WHERE nome = ?")) {
                    stmt2.setString(1, conteudoEscolhido);
                    ResultSet rs2 = stmt2.executeQuery();
                    if (rs2.next()) {
                        int conteudoId = rs2.getInt("id");
                        usuarioLogado.setDisciplinaEscolhida(conteudoId, conteudoEscolhido);
                        JOptionPane.showMessageDialog(null, "Disciplina escolhida com sucesso: " + conteudoEscolhido);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao escolher disciplina.", "ERRO", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void escolherMateria(Usuario usuarioLogado) {
        List<String> materias = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("SELECT nome FROM materias WHERE disciplinas_id = ?")) {

            stmt.setInt(1, usuarioLogado.getDisciplinaId());
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                materias.add(rs.getString("nome"));
            }

            String[] materiasArray = materias.toArray(new String[0]);
            String materiaEscolhida = (String) JOptionPane.showInputDialog(null, "Escolha uma matéria:", "Matérias Disponíveis", JOptionPane.QUESTION_MESSAGE, null, materiasArray, materiasArray[0]);

            if (materiaEscolhida != null) {
                try (PreparedStatement stmt2 = conn.prepareStatement("SELECT id FROM materias WHERE nome = ?")) {
                    stmt2.setString(1, materiaEscolhida);
                    ResultSet rs2 = stmt2.executeQuery();
                    if (rs2.next()) {
                        int materiaId = rs2.getInt("id");
                        usuarioLogado.setMateriaEscolhida(materiaId, materiaEscolhida);
                        JOptionPane.showMessageDialog(null, "Matéria escolhida com sucesso: " + materiaEscolhida);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao escolher matéria.", "ERRO", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void exibirConteudo(Usuario usuarioLogado) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("SELECT link, resumo FROM materias WHERE id = ?")) {

            stmt.setInt(1, usuarioLogado.getMateriaId());
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String link = rs.getString("link");
                String resumo = rs.getString("resumo");

                String mensagem = "Resumo: " + resumo + "\n\nDeseja abrir o link?";

                int opcao = JOptionPane.showConfirmDialog(null, mensagem, "Exibir Conteúdo", JOptionPane.YES_NO_OPTION);

                if (opcao == JOptionPane.YES_OPTION) {
                    java.awt.Desktop.getDesktop().browse(java.net.URI.create(link));
                }
            } else {
                JOptionPane.showMessageDialog(null, "Matéria não encontrada.", "ERRO", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao exibir conteúdo.", "ERRO", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void excluirConta(Usuario usuarioLogado) {
        int confirmacao = JOptionPane.showConfirmDialog(null, "Tem certeza de que deseja excluir sua conta?", "Confirmar Exclusão", JOptionPane.YES_NO_OPTION);

        if (confirmacao == JOptionPane.YES_OPTION) {
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                 PreparedStatement stmt = conn.prepareStatement("DELETE FROM usuarios WHERE email = ?")) {
                stmt.setString(1, usuarioLogado.getEmail());
                int affectedRows = stmt.executeUpdate();
                if (affectedRows > 0) {
                    JOptionPane.showMessageDialog(null, "Conta excluída com sucesso.");
                    usuarioLogado = null;
                } else {
                    JOptionPane.showMessageDialog(null, "Erro ao excluír a conta.", "ERRO", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Erro ao excluír a conta.", "ERRO", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
