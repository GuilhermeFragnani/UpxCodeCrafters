public class Usuario {
    private int id;
    private String nome;
    private String email;
    private String senha;
    private Integer disciplinaId;
    private String disciplinaNome;
    private Integer materiaId;
    private String materiaNome;

    public Usuario(int id, String nome, String email, String senha) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.disciplinaId = null;
        this.disciplinaNome = null;
        this.materiaId = null;
        this.materiaNome = null;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getSenha() {
        return senha;
    }

    public void setDisciplinaEscolhida(int disciplinaId, String disciplinaNome) {
        this.disciplinaId = disciplinaId;
        this.disciplinaNome = disciplinaNome;
    }

    public Integer getDisciplinaId() {
        return disciplinaId;
    }

    public String getDisciplinaNome() {
        return disciplinaNome;
    }

    public void setMateriaEscolhida(int materiaId, String materiaNome) {
        this.materiaId = materiaId;
        this.materiaNome = materiaNome;
    }

    public Integer getMateriaId() {
        return materiaId;
    }

    public String getMateriaNome() {
        return materiaNome;
    }

    public String imprimir() {
        return "Nome: " + nome + "\nEmail: " + email + "\nDisciplina Escolhida: " + (disciplinaNome != null ? disciplinaNome : "Nenhuma") + "\nMatéria Escolhida: " + (materiaNome != null ? materiaNome : "Nenhuma");
    }
}
